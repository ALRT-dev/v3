enum AppFlavor { dev, prod }
