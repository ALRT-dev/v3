enum MyHazardsTab {
  accepted,
  rejected,
}
